package com.satyam.temperatureconverterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
Button btnCelsiusToFahrenheit,btnCelsiusToKelvin,btnCelsiusToRankine,btnCelsiusToNewton,btnNext;
    String btnTxt="";
    String btnId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCelsiusToFahrenheit=findViewById(R.id.btnCelsiusToFahrenheit);
        btnCelsiusToKelvin=findViewById(R.id.btnCelsiusToKelvin);
        btnCelsiusToNewton=findViewById(R.id.btnCelsiusToNewton);
        btnCelsiusToRankine=findViewById(R.id.btnCelsiusToRankine);
        btnNext=findViewById(R.id.btnNext);

        btnCelsiusToRankine.setOnClickListener(this);
        btnCelsiusToFahrenheit.setOnClickListener(this);
        btnCelsiusToNewton.setOnClickListener(this);
        btnCelsiusToKelvin.setOnClickListener(this);
        btnNext.setOnClickListener(this);




    }

    @Override
    public void onClick(View v) {
        btnCelsiusToRankine.setBackgroundResource(R.drawable.buttonshape);
        btnCelsiusToRankine.setBackgroundColor(Color.GRAY);

        btnCelsiusToFahrenheit.setBackgroundResource(R.drawable.buttonshape);
        btnCelsiusToFahrenheit.setBackgroundColor(Color.GRAY);

        btnCelsiusToNewton.setBackgroundResource(R.drawable.buttonshape);
        btnCelsiusToNewton.setBackgroundColor(Color.GRAY);

        btnCelsiusToKelvin.setBackgroundResource(R.drawable.buttonshape);
        btnCelsiusToKelvin.setBackgroundColor(Color.GRAY);

        Button clickedButton =(Button) v;


        clickedButton.setBackgroundColor(Color.MAGENTA);

         if (clickedButton==btnCelsiusToFahrenheit){
              btnTxt=btnCelsiusToFahrenheit.getText().toString();
              btnId="1";

         }
        else if (clickedButton==btnCelsiusToKelvin){
              btnTxt=btnCelsiusToKelvin.getText().toString();
             btnId="2";

        }
       else if (clickedButton==btnCelsiusToNewton){

              btnTxt=btnCelsiusToNewton.getText().toString();
             btnId="3";


        }
        else if (clickedButton==btnCelsiusToRankine){
              btnTxt=btnCelsiusToRankine.getText().toString();
             btnId="4";


        }
        else {

             btnTxt="";

         }
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!btnTxt.isEmpty()){
                    Intent intent = new Intent(MainActivity.this, Calculation.class);
                    intent.putExtra("textOfBtn", btnTxt);
                    intent.putExtra("idOfBtn", btnId);

                    startActivity(intent);
                }else {
                    Toast.makeText(MainActivity.this, "Please Select Option", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}