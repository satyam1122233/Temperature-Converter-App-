package com.satyam.temperatureconverterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Calculation extends AppCompatActivity {

    TextView textFromBtn,outputTxt;
    EditText tempCelsius;
    Button outputBtn;
String textOfBtn,idOfBtn,inputText;
double temperaturefromEditText,calculation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculation);
        textOfBtn=getIntent().getStringExtra("textOfBtn");
        idOfBtn=getIntent().getStringExtra("idOfBtn");

        textFromBtn=findViewById(R.id.textFromBtn);
        outputBtn=findViewById(R.id.outputBtn);
        tempCelsius=findViewById(R.id.tempCelsius);
        outputTxt=findViewById(R.id.outputTxt);


        textFromBtn.setText(textOfBtn);

        outputBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                inputText = tempCelsius.getText().toString();


                if (!inputText.isEmpty()) {
                    temperaturefromEditText = Double.parseDouble(tempCelsius.getText().toString());

                    switch (idOfBtn) {
                        case "1":
                            calculation = ((temperaturefromEditText * 9 / 5) + 32);
                            outputTxt.setText(String.format("%.2f", calculation)); // Format to two decimal places
                            break;
                        case "2":
                            calculation = (temperaturefromEditText + 273.15);
                            outputTxt.setText(String.format("%.2f", calculation)); // Format to two decimal places
                            break;
                        case "3":
                            calculation = ((temperaturefromEditText + 273.15) * (9 / 5));
                            outputTxt.setText(String.format("%.2f", calculation)); // Format to two decimal places
                            break;
                        case "4":
                            calculation = (temperaturefromEditText * 33 / 100);
                            outputTxt.setText(String.format("%.2f", calculation)); // Format to two decimal places
                            break;


                    }
                }else {
                    // Handle case where input is empty
                    Toast.makeText(Calculation.this, "Please Enter Value", Toast.LENGTH_SHORT).show();
                }

            }
        });



    }
}